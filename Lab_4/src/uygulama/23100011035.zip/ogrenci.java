//23100011035 Emine Sude Alisarli
package uygulama;

public class ogrenci {
    private int ID;
    private String isimSoyisim;
    private double vizeNot;
    private double finalNot;
    private int sayac = 0;

    public ogrenci(String isimSoyisim, double vizeNot, double finalNot) {
        sayac++;
        this.ID = sayac;
        this.isimSoyisim = isimSoyisim;
        this.vizeNot = vizeNot;
        this.finalNot = finalNot;
    }
    public void BilgileriYazdir() {
        System.out.println("ID: " + ID);
        System.out.println("İsim Soyisim: " + isimSoyisim);
        System.out.println("Vize Notu: " + vizeNot);
        System.out.println("Final Notu: " + finalNot);
        System.out.println();
    }
    public double GecmeNotuHesapla(double vizeNot, double finalNot) {
    	double ortalama;
    	ortalama = (vizeNot * 0.4) + (finalNot * 0.6);
    	return ortalama;
    }

    public String HarfHesapla() {
        double gecmeNotu = 0;
        gecmeNotu = GecmeNotuHesapla(vizeNot,finalNot);

        if (gecmeNotu >= 90) {
        	return "AA";
        }
        else if (gecmeNotu >= 80) {
        	return "BA";
        }
        else if (gecmeNotu >= 70) {
        	return "BB";
        }
        else if (gecmeNotu >= 60) {
        	return "CB";
        }
        else if (gecmeNotu >= 50) {
        	return "CC";
        }
        else {
        	return "FF";
        }
    }
}
