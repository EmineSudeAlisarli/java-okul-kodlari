//23100011035 Emine Sude Alisarli
package uygulama;

public class main {

	public static void main(String[] args) {
		ogrenci ogrenci1 = new ogrenci("Emine Sude",84,97);
		ogrenci1.BilgileriYazdir();
		System.out.println("Ortalama:"+ogrenci1.GecmeNotuHesapla(84,97));
		System.out.println("Gecme notu:"+ogrenci1.HarfHesapla());
		
		
	}

}
